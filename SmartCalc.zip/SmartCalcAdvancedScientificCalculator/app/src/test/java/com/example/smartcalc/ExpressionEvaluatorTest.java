package com.example.smartcalc;

import com.example.smartcalc.util.ExpressionEvaluator;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class ExpressionEvaluatorTest {

    private ExpressionEvaluator evaluator;

    @Before
    public void setUp() {
        evaluator = new ExpressionEvaluator();
    }

    @Test
    public void testBasicArithmetic() throws Exception {
        assertEquals(5.0, evaluator.eval("2 + 3", true), 1e-9);
        assertEquals(10.0, evaluator.eval("2 * 5", true), 1e-9);
        assertEquals(2.5, evaluator.eval("5 / 2", true), 1e-9);
        assertEquals(-1.0, evaluator.eval("2 - 3", true), 1e-9);
    }

    @Test
    public void testTrigDegreesAndRadians() throws Exception {
        assertEquals(0.5, evaluator.eval("sin(30)", true), 1e-9);
        assertEquals(1.0, evaluator.eval("sin(pi / 2)", false), 1e-9);
        assertEquals(1.0, evaluator.eval("cos(0)", true), 1e-9);
    }

    @Test
    public void testVariables() throws Exception {
        Map<String, Double> vars = new HashMap<>();
        vars.put("x", 4.0);
        assertEquals(16.0, evaluator.eval("x^2", true, vars), 1e-9);
        assertEquals(2.0, evaluator.eval("sqrt(x)", true, vars), 1e-9);
    }

    @Test
    public void testPowerAndFactorial() throws Exception {
        assertEquals(8.0, evaluator.eval("2^3", true), 1e-9);
        assertEquals(24.0, evaluator.eval("4!", true), 1e-9);
    }
}
