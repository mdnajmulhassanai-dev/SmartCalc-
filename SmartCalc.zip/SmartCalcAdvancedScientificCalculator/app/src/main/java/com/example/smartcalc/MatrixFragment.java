package com.example.smartcalc;

import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.smartcalc.util.Fmt;

public class MatrixFragment extends Fragment {

    private int n = 2;
    private final EditText[][] A = new EditText[4][4];
    private final EditText[][] B = new EditText[4][4];
    private GridLayout gridA, gridB;
    private TextView result;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_matrix, parent, false);
        gridA  = root.findViewById(R.id.gridA);
        gridB  = root.findViewById(R.id.gridB);
        result = root.findViewById(R.id.matrixResult);

        ((RadioButton) root.findViewById(R.id.rb2)).setOnCheckedChangeListener(
                (b, c) -> { if (c) { n = 2; buildGrids(); } });
        ((RadioButton) root.findViewById(R.id.rb3)).setOnCheckedChangeListener(
                (b, c) -> { if (c) { n = 3; buildGrids(); } });
        ((RadioButton) root.findViewById(R.id.rb4)).setOnCheckedChangeListener(
                (b, c) -> { if (c) { n = 4; buildGrids(); } });

        root.findViewById(R.id.btnAdd).setOnClickListener(v -> op("add"));
        root.findViewById(R.id.btnSub).setOnClickListener(v -> op("sub"));
        root.findViewById(R.id.btnMul).setOnClickListener(v -> op("mul"));
        root.findViewById(R.id.btnDet).setOnClickListener(v -> op("det"));
        root.findViewById(R.id.btnInv).setOnClickListener(v -> op("inv"));
        root.findViewById(R.id.btnTr).setOnClickListener(v -> op("tr"));

        buildGrids();
        return root;
    }

    private void buildGrids() {
        gridA.removeAllViews();
        gridB.removeAllViews();
        gridA.setColumnCount(n);
        gridB.setColumnCount(n);

        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                A[r][c] = makeCell(gridA);
                B[r][c] = makeCell(gridB);
            }
        }
    }

    private EditText makeCell(GridLayout parent) {
        EditText e = new EditText(requireContext());
        e.setInputType(InputType.TYPE_CLASS_NUMBER
                | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText("0");
        e.setGravity(Gravity.CENTER);
        e.setTextColor(ContextCompat.getColor(requireContext(), R.color.text));
        e.setTextSize(16);
        e.setBackgroundResource(R.drawable.cell_bg);
        e.setPadding(8, 8, 8, 8);

        GridLayout.LayoutParams p = new GridLayout.LayoutParams();
        p.width = 0;
        p.height = GridLayout.LayoutParams.WRAP_CONTENT;
        p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        p.setMargins(4, 4, 4, 4);
        parent.addView(e, p);
        return e;
    }

    private double[][] read(EditText[][] m) {
        double[][] out = new double[n][n];
        for (int r = 0; r < n; r++)
            for (int c = 0; c < n; c++) {
                String s = m[r][c].getText().toString().trim();
                try { out[r][c] = s.isEmpty() ? 0 : Double.parseDouble(s); }
                catch (NumberFormatException e) { out[r][c] = 0; }
            }
        return out;
    }

    private void op(String kind) {
        double[][] a = read(A), b = read(B);
        try {
            switch (kind) {
                case "add": result.setText("A + B =\n" + show(add(a, b))); break;
                case "sub": result.setText("A − B =\n" + show(sub(a, b))); break;
                case "mul": result.setText("A × B =\n" + show(mul(a, b))); break;
                case "det": result.setText("det(A) = " + Fmt.num(det(a))
                        + "\ndet(B) = " + Fmt.num(det(b))); break;
                case "inv": {
                    double[][] ia = inverse(a);
                    double[][] ib = inverse(b);
                    result.setText("A⁻¹ =\n" + (ia == null ? "singular" : show(ia))
                            + "\nB⁻¹ =\n" + (ib == null ? "singular" : show(ib)));
                    break;
                }
                case "tr": result.setText("Aᵀ =\n" + show(transpose(a))
                        + "\nBᵀ =\n" + show(transpose(b))); break;
            }
        } catch (Exception ex) {
            result.setText("Error: " + ex.getMessage());
        }
    }

    private double[][] add(double[][] a, double[][] b) {
        double[][] r = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) r[i][j] = a[i][j] + b[i][j];
        return r;
    }

    private double[][] sub(double[][] a, double[][] b) {
        double[][] r = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) r[i][j] = a[i][j] - b[i][j];
        return r;
    }

    private double[][] mul(double[][] a, double[][] b) {
        double[][] r = new double[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                double s = 0;
                for (int k = 0; k < n; k++) s += a[i][k] * b[k][j];
                r[i][j] = s;
            }
        return r;
    }

    private double[][] transpose(double[][] a) {
        double[][] r = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) r[i][j] = a[j][i];
        return r;
    }

    private double det(double[][] m) {
        if (m.length == 1) return m[0][0];
        if (m.length == 2) return m[0][0] * m[1][1] - m[0][1] * m[1][0];
        double d = 0;
        for (int c = 0; c < m.length; c++) {
            double[][] sub = new double[m.length - 1][m.length - 1];
            for (int i = 1; i < m.length; i++)
                for (int j = 0, k = 0; j < m.length; j++) {
                    if (j == c) continue;
                    sub[i - 1][k++] = m[i][j];
                }
            d += ((c % 2 == 0) ? 1 : -1) * m[0][c] * det(sub);
        }
        return d;
    }

    /** Gauss-Jordan inversion with partial pivoting. Returns null if singular. */
    private double[][] inverse(double[][] m) {
        int sz = m.length;
        double[][] a = new double[sz][2 * sz];
        for (int i = 0; i < sz; i++) {
            System.arraycopy(m[i], 0, a[i], 0, sz);
            a[i][sz + i] = 1;
        }
        for (int col = 0; col < sz; col++) {
            int piv = col;
            for (int r = col + 1; r < sz; r++)
                if (Math.abs(a[r][col]) > Math.abs(a[piv][col])) piv = r;
            if (Math.abs(a[piv][col]) < 1e-12) return null;
            double[] t = a[col]; a[col] = a[piv]; a[piv] = t;

            double d = a[col][col];
            for (int j = 0; j < 2 * sz; j++) a[col][j] /= d;

            for (int r = 0; r < sz; r++) {
                if (r == col) continue;
                double f = a[r][col];
                for (int j = 0; j < 2 * sz; j++) a[r][j] -= f * a[col][j];
            }
        }
        double[][] inv = new double[sz][sz];
        for (int i = 0; i < sz; i++)
            for (int j = 0; j < sz; j++) inv[i][j] = a[i][sz + j];
        return inv;
    }

    private String show(double[][] m) {
        StringBuilder sb = new StringBuilder();
        for (double[] row : m) {
            sb.append("[ ");
            for (double v : row) sb.append(String.format("%10s ", Fmt.num(v)));
            sb.append("]\n");
        }
        return sb.toString();
    }
}