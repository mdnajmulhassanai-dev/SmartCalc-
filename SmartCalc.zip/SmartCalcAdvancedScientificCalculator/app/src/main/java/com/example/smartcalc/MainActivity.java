package com.example.smartcalc;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottomNav);

        if (savedInstanceState == null) {
            // প্রথমবার অ্যাপ ওপেন হলে ক্যালকুলেটর লোড হবে
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, new CalculatorFragment())
                    .commit();

            // ওয়েলকাম পপআপ শো করবে
            showWelcomeDialog();
        }

        nav.setOnItemSelectedListener(item -> {
            Fragment f;
            int id = item.getItemId();
            if (id == R.id.nav_convert)      f = new ConverterFragment();
            else if (id == R.id.nav_matrix)  f = new MatrixFragment();
            else if (id == R.id.nav_solve)   f = new SolverFragment();
            else if (id == R.id.nav_stats)   f = new StatsFragment();
            else                             f = new CalculatorFragment();

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, f)
                    .commit();
            return true;
        });
    }

    // --- ওয়েলকাম পপআপ মেথড ---
    private void showWelcomeDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_welcome);
        dialog.setCancelable(true);

        if (dialog.getWindow() != null) {
            // পেছনের অংশ ট্রান্সপারেন্ট করা
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            // ডায়ালগের সাইজ সেট করা
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            // স্মুথ ফেড-ইন অ্যানিমেশন
            dialog.getWindow().getDecorView().setAlpha(0f);
            dialog.getWindow().getDecorView().animate()
                    .alpha(1f)
                    .setDuration(300)
                    .setInterpolator(AnimationUtils.loadInterpolator(this, android.R.anim.decelerate_interpolator))
                    .start();
        }

        // "Let's Calculate!" বাটনে ক্লিক করলে ডায়ালগ বন্ধ হবে
        dialog.findViewById(R.id.btnLetsCalculate).setOnClickListener(v -> {
            dialog.dismiss();
        });

        dialog.show();
    }
}