package com.example.smartcalc.util;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Fmt {
    private Fmt() {}

    // DecimalFormat is not thread-safe → use ThreadLocal (allocation-free per call)
    private static final ThreadLocal<DecimalFormat> SCI = new ThreadLocal<DecimalFormat>() {
        @Override protected DecimalFormat initialValue() {
            return new DecimalFormat("0.#########E0",
                    DecimalFormatSymbols.getInstance(Locale.US));
        }
    };
    private static final ThreadLocal<DecimalFormat> DEC = new ThreadLocal<DecimalFormat>() {
        @Override protected DecimalFormat initialValue() {
            return new DecimalFormat("0.##########",
                    DecimalFormatSymbols.getInstance(Locale.US));
        }
    };

    public static String num(double v) {
        if (Double.isNaN(v)) return "NaN";
        if (Double.isInfinite(v)) return v > 0 ? "∞" : "−∞";
        if (v == 0) return "0";
        double a = Math.abs(v);
        if (a >= 1e12 || a < 1e-9) return SCI.get().format(v);
        return DEC.get().format(v);
    }
}