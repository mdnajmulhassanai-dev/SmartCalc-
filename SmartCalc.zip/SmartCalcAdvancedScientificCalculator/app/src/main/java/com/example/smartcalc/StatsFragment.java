package com.example.smartcalc;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartcalc.util.Fmt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class StatsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_stats, parent, false);
        EditText data = root.findViewById(R.id.etData);
        TextView out = root.findViewById(R.id.tvStats);

        root.findViewById(R.id.btnCalcStats).setOnClickListener(v -> {
            try { out.setText(analyze(data.getText().toString())); }
            catch (Exception e) { out.setText("Invalid input: " + e.getMessage()); }
        });
        return root;
    }

    private String analyze(String raw) throws Exception {
        String[] parts = raw.trim().split("[,\\s]+");
        List<Double> vals = new ArrayList<>();
        for (String p : parts) if (!p.isEmpty()) vals.add(Double.parseDouble(p));
        if (vals.isEmpty()) throw new Exception("no numbers");

        Collections.sort(vals);
        int n = vals.size();
        double sum = 0, min = vals.get(0), max = vals.get(n - 1);
        for (double d : vals) sum += d;
        double mean = sum / n;

        double median = percentile(vals, 50);
        double q1 = percentile(vals, 25);
        double q3 = percentile(vals, 75);
        double iqr = q3 - q1;

        double sqSum = 0;
        for (double d : vals) sqSum += Math.pow(d - mean, 2);
        double varPop = sqSum / n;
        double varSmp = n > 1 ? sqSum / (n - 1) : 0;

        Map<Double, Integer> freq = new TreeMap<>();
        for (double d : vals) freq.merge(d, 1, Integer::sum);
        int maxF = Collections.max(freq.values());
        StringBuilder modes = new StringBuilder();
        if (maxF <= 1) modes.append("none");
        else for (Map.Entry<Double, Integer> e : freq.entrySet())
            if (e.getValue() == maxF) modes.append(Fmt.num(e.getKey())).append(' ');

        return "n              = " + n + "\n" +
                "Sum            = " + Fmt.num(sum) + "\n" +
                "Mean (μ)       = " + Fmt.num(mean) + "\n" +
                "Median         = " + Fmt.num(median) + "\n" +
                "Mode           = " + modes.toString().trim() + "\n" +
                "Min            = " + Fmt.num(min) + "\n" +
                "Max            = " + Fmt.num(max) + "\n" +
                "Range          = " + Fmt.num(max - min) + "\n" +
                "Q1             = " + Fmt.num(q1) + "\n" +
                "Q3             = " + Fmt.num(q3) + "\n" +
                "IQR            = " + Fmt.num(iqr) + "\n" +
                "Variance (σ²)  = " + Fmt.num(varPop) + "\n" +
                "Variance (s²)  = " + Fmt.num(varSmp) + "\n" +
                "Std dev (σ)    = " + Fmt.num(Math.sqrt(varPop)) + "\n" +
                "Std dev (s)    = " + Fmt.num(Math.sqrt(varSmp)) + "\n" +
                "Geo. mean      = " + Fmt.num(geometricMean(vals)) + "\n" +
                "Harm. mean     = " + Fmt.num(harmonicMean(vals));
    }

    private double percentile(List<Double> sorted, double p) {
        int n = sorted.size();
        if (n == 1) return sorted.get(0);
        double pos = (p / 100.0) * (n - 1);
        int lo = (int) Math.floor(pos);
        int hi = (int) Math.ceil(pos);
        if (lo == hi) return sorted.get(lo);
        return sorted.get(lo) * (hi - pos) + sorted.get(hi) * (pos - lo);
    }

    private double geometricMean(List<Double> v) {
        double s = 0;
        for (double d : v) { if (d <= 0) return Double.NaN; s += Math.log(d); }
        return Math.exp(s / v.size());
    }

    private double harmonicMean(List<Double> v) {
        double s = 0;
        for (double d : v) { if (d == 0) return Double.NaN; s += 1.0 / d; }
        return v.size() / s;
    }
}