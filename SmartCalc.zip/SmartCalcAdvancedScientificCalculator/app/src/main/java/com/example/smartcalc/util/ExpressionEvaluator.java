package com.example.smartcalc.util;

import java.util.HashMap;
import java.util.Map;

public class ExpressionEvaluator {

    private String s;
    private int i;
    private boolean deg;
    private double ans = 0;
    private Map<String, Double> vars = new HashMap<>();

    public void setAns(double a) { ans = a; }

    public double eval(String expression, boolean degrees) throws Exception {
        return eval(expression, degrees, null);
    }

    public double eval(String expression, boolean degrees, Map<String, Double> variables) throws Exception {
        this.vars = variables != null ? variables : new HashMap<>();
        this.s = normalize(expression);
        this.i = 0;
        this.deg = degrees;
        if (s.isEmpty()) throw new Exception("Empty expression");
        double v = parseExpr();
        if (i < s.length()) throw new Exception("Unexpected '" + s.charAt(i) + "'");
        return v;
    }

    private String normalize(String e) {
        return e.replace("×", "*").replace("÷", "/")
                .replace("−", "-").replace("–", "-")
                .replace("π", "pi").replace("√", "sqrt")
                .replace(" ", "");
    }

    private double parseExpr() throws Exception {
        double v = parseTerm();
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '+') { i++; v += parseTerm(); }
            else if (c == '-') { i++; v -= parseTerm(); }
            else break;
        }
        return v;
    }

    private double parseTerm() throws Exception {
        double v = parseUnary();
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '*') { i++; v *= parseUnary(); }
            else if (c == '/') { i++; v /= parseUnary(); }
            else if (c == '%') { i++; v %= parseUnary(); }
            else if (c == '(' || Character.isLetter(c)) v *= parseUnary(); // implicit multiply
            else break;
        }
        return v;
    }

    private double parseUnary() throws Exception {
        if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) {
            char sign = s.charAt(i++);
            double v = parseUnary();
            return sign == '-' ? -v : v;
        }
        return parsePower();
    }

    private double parsePower() throws Exception {
        double base = parseAtom();
        if (i < s.length() && s.charAt(i) == '^') {
            i++;
            double exp = parseUnary();          // right-associative
            return Math.pow(base, exp);
        }
        return base;
    }

    private double parseAtom() throws Exception {
        // Number (with optional scientific notation)
        if (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) {
            int start = i;
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) i++;
            if (i + 1 < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                int j = i + 1;
                if (j < s.length() && (s.charAt(j) == '+' || s.charAt(j) == '-')) j++;
                if (j < s.length() && Character.isDigit(s.charAt(j))) {
                    while (j < s.length() && Character.isDigit(s.charAt(j))) j++;
                    i = j;
                }
            }
            return postfix(Double.parseDouble(s.substring(start, i)));
        }

        // Parenthesis
        if (i < s.length() && s.charAt(i) == '(') {
            i++;
            double v = parseExpr();
            if (i < s.length() && s.charAt(i) == ')') i++;
            else throw new Exception("Missing ')'");
            return postfix(v);
        }

        // Identifier (constant, variable, or function)
        if (i < s.length() && Character.isLetter(s.charAt(i))) {
            int start = i;
            while (i < s.length() && Character.isLetterOrDigit(s.charAt(i))) i++;
            String name = s.substring(start, i).toLowerCase();

            if (name.equals("pi"))  return postfix(Math.PI);
            if (name.equals("e"))   return postfix(Math.E);
            if (name.equals("phi")) return postfix((1 + Math.sqrt(5)) / 2);
            if (name.equals("ans")) return postfix(ans);
            if (vars.containsKey(name)) return postfix(vars.get(name));

            if (i < s.length() && s.charAt(i) == '(') {
                i++;
                double arg = parseExpr();
                double arg2 = Double.NaN;
                if (i < s.length() && s.charAt(i) == ',') { i++; arg2 = parseExpr(); }
                if (i < s.length() && s.charAt(i) == ')') i++;
                else throw new Exception("Missing ')'");
                return postfix(apply(name, arg, arg2));
            }
            throw new Exception("Unknown '" + name + "'");
        }
        throw new Exception("Unexpected end of expression");
    }

    private double postfix(double v) throws Exception {
        while (i < s.length() && s.charAt(i) == '!') {
            i++;
            v = factorial(v);
        }
        return v;
    }

    private double apply(String f, double x, double y) throws Exception {
        switch (f) {
            case "sin":  return Math.sin(deg ? Math.toRadians(x) : x);
            case "cos":  return Math.cos(deg ? Math.toRadians(x) : x);
            case "tan":  return Math.tan(deg ? Math.toRadians(x) : x);
            case "asin": return deg ? Math.toDegrees(Math.asin(x)) : Math.asin(x);
            case "acos": return deg ? Math.toDegrees(Math.acos(x)) : Math.acos(x);
            case "atan": return deg ? Math.toDegrees(Math.atan(x)) : Math.atan(x);
            case "sinh": return Math.sinh(x);
            case "cosh": return Math.cosh(x);
            case "tanh": return Math.tanh(x);
            case "ln":   return Math.log(x);
            case "log":  return Double.isNaN(y) ? Math.log10(x) : Math.log(x) / Math.log(y);
            case "log2": return Math.log(x) / Math.log(2);
            case "sqrt": return Math.sqrt(x);
            case "cbrt": return Math.cbrt(x);
            case "abs":  return Math.abs(x);
            case "exp":  return Math.exp(x);
            case "inv":  return 1.0 / x;
            case "fact": return factorial(x);
            case "round":return Math.round(x);
            case "floor":return Math.floor(x);
            case "ceil": return Math.ceil(x);
            case "nroot":return Math.pow(x, 1.0 / y);
            case "pow":  return Math.pow(x, y);
            default: throw new Exception("Unknown function '" + f + "'");
        }
    }

    private double factorial(double x) throws Exception {
        if (x < 0 || x != Math.floor(x))
            throw new Exception("Factorial requires a non-negative integer");
        if (x > 170) return Double.POSITIVE_INFINITY;
        double r = 1;
        for (int k = 2; k <= (int) x; k++) r *= k;
        return r;
    }
}