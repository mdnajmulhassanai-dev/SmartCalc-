package com.example.smartcalc;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.smartcalc.util.ExpressionEvaluator;
import com.example.smartcalc.util.Fmt;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class CalculatorFragment extends Fragment {

    private EditText tvExpr;
    private TextView tvResult;
    private final StringBuilder expr = new StringBuilder();
    private final ExpressionEvaluator evaluator = new ExpressionEvaluator();
    private final List<String> history = new ArrayList<>();

    private boolean degrees = true;
    private double ans = 0, memory = 0;
    private boolean justEvaluated = false;

    private float numTextSize, fnTextSize, extraTextSize;
    private int btnMargin;

    private static final int[][] PAD_LABELS = {
            {R.string.fn_sin, R.string.fn_cos, R.string.fn_tan, R.string.fn_ln, R.string.fn_log},
            {R.string.fn_sqrt, R.string.fn_sq, R.string.fn_pow, R.string.paren_l, R.string.paren_r},
            {R.string.num_7, R.string.num_8, R.string.num_9, R.string.op_div, R.string.op_del},
            {R.string.num_4, R.string.num_5, R.string.num_6, R.string.op_mul, R.string.op_ac},
            {R.string.num_1, R.string.num_2, R.string.num_3, R.string.op_sub, R.string.op_ans},
            {R.string.num_0, R.string.num_dot, R.string.num_pi, R.string.op_add, R.string.op_eq}
    };
    private static final String[][] PAD_TOKENS = {
            {"sin", "cos", "tan", "ln", "log"},
            {"√", "x²", "xʸ", "(", ")"},
            {"7", "8", "9", "÷", "⌫"},
            {"4", "5", "6", "×", "AC"},
            {"1", "2", "3", "−", "ANS"},
            {"0", ".", "π", "+", "="}
    };
    private static final int[][] PAD_STYLES = {
            {1, 1, 1, 1, 1},
            {1, 1, 1, 1, 1},
            {0, 0, 0, 2, 4},
            {0, 0, 0, 2, 4},
            {0, 0, 0, 2, 1},
            {0, 0, 0, 2, 3}
    };

    private static final int[] EXTRA_LABELS = {
            R.string.ext_e, R.string.ext_fact, R.string.ext_pct, R.string.ext_abs,
            R.string.ext_inv, R.string.ext_10pow, R.string.ext_epow,
            R.string.ext_asin, R.string.ext_acos, R.string.ext_atan,
            R.string.ext_sinh, R.string.ext_cosh, R.string.ext_tanh,
            R.string.ext_log2, R.string.ext_cbrt, R.string.ext_rand
    };
    private static final String[] EXTRA_TOKENS = {
            "e", "!", "%", "|x|", "1/x", "10ˣ", "eˣ",
            "asin", "acos", "atan", "sinh", "cosh", "tanh",
            "log₂", "∛", "rand"
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_calculator, parent, false);
        tvExpr = root.findViewById(R.id.tvExpr);
        tvResult = root.findViewById(R.id.tvResult);
        tvExpr.setShowSoftInputOnFocus(false);

        calculateResponsiveSizes();
        buildKeypad(root.findViewById(R.id.padContainer));
        buildExtras(root.findViewById(R.id.extrasRow));
        wireTopBar(root);

        if (savedInstanceState != null) {
            expr.append(savedInstanceState.getString("expr", ""));
            ans = savedInstanceState.getDouble("ans", 0);
            degrees = savedInstanceState.getBoolean("deg", true);
        }
        updateModeChips(root);
        updateDisplay(expr.length());
        return root;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("expr", expr.toString());
        out.putDouble("ans", ans);
        out.putBoolean("deg", degrees);
    }

    private void calculateResponsiveSizes() {
        int screenWidthDp = getResources().getConfiguration().screenWidthDp;
        numTextSize = Math.max(18f, Math.min(26f, screenWidthDp / 16f));
        fnTextSize = Math.max(13f, Math.min(18f, screenWidthDp / 22f));
        extraTextSize = Math.max(13f, Math.min(17f, screenWidthDp / 24f));
        btnMargin = dpToPx(Math.max(2, Math.min(5, screenWidthDp / 80)));
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    // --- কার্সরের পজিশন সেফলি বের করা (placeholder "0" হ্যান্ডেল করে) ---
    private int safeCursor() {
        int pos = tvExpr.getSelectionStart();
        if (pos < 0) pos = expr.length();
        // যদি expr খালি থাকে (placeholder "0"), কার্সর সবসময় 0 ধরব
        return Math.min(pos, expr.length());
    }

    // --- সিলেকশন রেঞ্জ সেফলি বের করা ---
    private int[] safeSelection() {
        int s = tvExpr.getSelectionStart();
        int e = tvExpr.getSelectionEnd();
        if (s > e) { int t = s; s = e; e = t; }
        s = Math.max(0, Math.min(s, expr.length()));
        e = Math.max(0, Math.min(e, expr.length()));
        return new int[]{s, e};
    }

    private void buildKeypad(LinearLayout container) {
        for (int r = 0; r < PAD_LABELS.length; r++) {
            LinearLayout row = new LinearLayout(requireContext());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

            for (int c = 0; c < PAD_LABELS[r].length; c++) {
                MaterialButton b = new MaterialButton(requireContext());
                b.setText(PAD_LABELS[r][c]);
                b.setTag(PAD_TOKENS[r][c]);
                b.setAllCaps(false);
                b.setInsetTop(0);
                b.setInsetBottom(0);
                b.setCornerRadius(dpToPx(14));
                b.setPadding(0, 0, 0, 0);

                int type = PAD_STYLES[r][c];
                if (type == 0) {
                    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, numTextSize);
                    b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.surface)));
                    b.setTextColor(ContextCompat.getColor(requireContext(), R.color.text));
                } else if (type == 1) {
                    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, fnTextSize);
                    b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.surface2)));
                    b.setTextColor(ContextCompat.getColor(requireContext(), R.color.textDim));
                } else if (type == 2) {
                    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, numTextSize);
                    b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.op)));
                    b.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark));
                } else if (type == 3) {
                    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, numTextSize);
                    b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.accent)));
                    b.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark));
                } else if (type == 4) {
                    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, fnTextSize);
                    b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.danger)));
                    b.setTextColor(ContextCompat.getColor(requireContext(), R.color.dark));
                }

                b.setOnClickListener(this::onKey);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
                lp.setMargins(btnMargin, btnMargin, btnMargin, btnMargin);
                row.addView(b, lp);
            }
            container.addView(row);
        }
    }

    private void buildExtras(LinearLayout row) {
        for (int i = 0; i < EXTRA_LABELS.length; i++) {
            MaterialButton b = new MaterialButton(requireContext());
            b.setText(EXTRA_LABELS[i]);
            b.setTag(EXTRA_TOKENS[i]);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, extraTextSize);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            b.setPadding(dpToPx(14), 0, dpToPx(14), 0);
            b.setInsetTop(0);
            b.setInsetBottom(0);
            b.setCornerRadius(dpToPx(12));

            b.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.surface)));
            b.setTextColor(ContextCompat.getColor(requireContext(), R.color.accent2));

            b.setOnClickListener(this::onExtra);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.setMargins(dpToPx(3), 0, dpToPx(3), 0);
            row.addView(b, lp);
        }
    }

    private void wireTopBar(View root) {
        root.findViewById(R.id.btnDeg).setOnClickListener(v -> { degrees = true; updateModeChips(root); updateDisplay(); });
        root.findViewById(R.id.btnRad).setOnClickListener(v -> { degrees = false; updateModeChips(root); updateDisplay(); });
        root.findViewById(R.id.btnMc).setOnClickListener(v -> {
            memory = 0;
            Toast.makeText(requireContext(), R.string.msg_mem_cleared, Toast.LENGTH_SHORT).show();
        });
        root.findViewById(R.id.btnMr).setOnClickListener(v -> {
            justEvaluated = false;
            int cursor = safeCursor();
            expr.insert(cursor, Fmt.num(memory));
            updateDisplay(cursor + Fmt.num(memory).length());
        });
        root.findViewById(R.id.btnMPlus).setOnClickListener(v -> {
            memory += currentResult();
            Toast.makeText(requireContext(), getString(R.string.msg_mem_value, Fmt.num(memory)), Toast.LENGTH_SHORT).show();
        });
        root.findViewById(R.id.btnHist).setOnClickListener(v -> showHistory());
        root.findViewById(R.id.btnGraph).setOnClickListener(v -> startActivity(new Intent(requireContext(), GraphActivity.class)));
    }

    private void updateModeChips(View root) {
        MaterialButton deg = root.findViewById(R.id.btnDeg);
        MaterialButton rad = root.findViewById(R.id.btnRad);

        int accent = ContextCompat.getColor(requireContext(), R.color.accent);
        int surface = ContextCompat.getColor(requireContext(), R.color.surface2);
        int white = ContextCompat.getColor(requireContext(), R.color.dark);
        int textDim = ContextCompat.getColor(requireContext(), R.color.textDim);

        if (degrees) {
            deg.setBackgroundTintList(ColorStateList.valueOf(accent));
            deg.setTextColor(white);
            rad.setBackgroundTintList(ColorStateList.valueOf(surface));
            rad.setTextColor(textDim);
        } else {
            rad.setBackgroundTintList(ColorStateList.valueOf(accent));
            rad.setTextColor(white);
            deg.setBackgroundTintList(ColorStateList.valueOf(surface));
            deg.setTextColor(textDim);
        }
    }

    private void onKey(View v) {
        String t = (String) v.getTag();
        if ("AC".equals(t)) {
            expr.setLength(0);
            justEvaluated = false;
            updateDisplay(0);
            return;
        }
        if ("⌫".equals(t)) {
            handleBackspace();
            return;
        }
        if ("=".equals(t)) { compute(); return; }
        insert(t);
    }

    // --- ব্যাকস্পেস: কার্সরের পজিশন অনুযায়ী ডিলিট ---
    private void handleBackspace() {
        if (justEvaluated) {
            // শেষ রেজাল্টের পর ব্যাকস্পেস চাপলে সব ক্লিয়ার
            expr.setLength(0);
            justEvaluated = false;
            updateDisplay(0);
            return;
        }
        if (expr.length() == 0) return;

        int[] sel = safeSelection();
        int s = sel[0], e = sel[1];

        if (s != e) {
            // সিলেকশন থাকলে পুরো সিলেকশন ডিলিট
            expr.replace(s, e, "");
            updateDisplay(s);
        } else if (s > 0) {
            // কার্সরের ঠিক আগের অক্ষর ডিলিট
            expr.deleteCharAt(s - 1);
            updateDisplay(s - 1);
        }
    }

    private void onExtra(View v) {
        String t = (String) v.getTag();
        switch (t) {
            case "|x|":  insert("abs("); break;
            case "1/x":  insert("inv("); break;
            case "10ˣ":  insert("10^"); break;
            case "eˣ":   insert("e^"); break;
            case "log₂": insert("log2("); break;
            case "∛":    insert("cbrt("); break;
            default:     insert(t);
        }
    }

    // --- মূল ফিক্স: কার্সরের পজিশনে ইনসার্ট ---
    private void insert(String token) {
        // justEvaluated এর পর অঙ্ক/ফাংশন চাপলে নতুন এক্সপ্রেশন শুরু
        int[] sel = safeSelection();
        int cursor = sel[0];

        boolean startsNew = justEvaluated && isFreshStart(token) && cursor == expr.length();
        if (startsNew) {
            expr.setLength(0);
            cursor = 0;
            sel = new int[]{0, 0};
        }
        justEvaluated = false;

        // টোকেনকে টেক্সটে রূপান্তর
        String textToInsert;
        switch (token) {
            case "sin": case "cos": case "tan": case "ln": case "log":
            case "asin": case "acos": case "atan":
            case "sinh": case "cosh": case "tanh":
                textToInsert = token + "("; break;
            case "√":   textToInsert = "√("; break;
            case "x²":  textToInsert = "^2"; break;
            case "xʸ":  textToInsert = "^"; break;
            case "ANS": textToInsert = "ans"; break;
            default:    textToInsert = token;
        }

        int s = sel[0], e = sel[1];

        if (s != e) {
            // সিলেকশন থাকলে সেটিকে রিপ্লেস
            expr.replace(s, e, textToInsert);
        } else {
            // কার্সরের পজিশনে ইনসার্ট
            expr.insert(s, textToInsert);
        }

        // নতুন কার্সর পজিশন: ইনসার্ট করা টেক্সটের ঠিক পরে
        updateDisplay(s + textToInsert.length());
    }

    private boolean isFreshStart(String token) {
        return !(token.equals("+") || token.equals("−") || token.equals("×")
                || token.equals("÷") || token.equals("%") || token.equals("^")
                || token.equals("xʸ") || token.equals("x²") || token.equals("!"));
    }

    private void compute() {
        if (expr.length() == 0) return;
        try {
            evaluator.setAns(ans);
            double v = evaluator.eval(expr.toString(), degrees);
            String res = Fmt.num(v);
            history.add(0, expr + " = " + res);
            if (history.size() > 50) history.remove(history.size() - 1);
            ans = v;
            justEvaluated = true;

            tvResult.setText(getString(R.string.eq_prefix, res));

            expr.setLength(0);
            expr.append(res);

            // কম্পিউটের পর কার্সর শেষে
            updateDisplay(expr.length());
        } catch (Exception e) {
            tvResult.setText(R.string.msg_error);
            tvResult.setTextColor(ContextCompat.getColor(requireContext(), R.color.danger));
            Toast.makeText(requireContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private double currentResult() {
        try { evaluator.setAns(ans); return evaluator.eval(expr.toString(), degrees); }
        catch (Exception e) { return 0; }
    }

    private void updateDisplay() {
        updateDisplay(safeCursor());
    }

    // --- আপডেটেড updateDisplay যা কার্সর পজিশন প্রিজার্ভ করে ---
    private void updateDisplay(int cursorPos) {
        String display = expr.length() == 0 ? getString(R.string.zero) : expr.toString();
        tvExpr.setText(display);

        if (expr.length() == 0) {
            // placeholder "0" অবস্থায় কার্সর শেষে কিন্তু ইনভিজিবল
            tvExpr.setSelection(display.length());
            tvExpr.setCursorVisible(false);
        } else {
            int pos = Math.max(0, Math.min(cursorPos, display.length()));
            tvExpr.setSelection(pos);
            tvExpr.setCursorVisible(true);
        }

        tvResult.setTextColor(ContextCompat.getColor(requireContext(), R.color.text));
        if (expr.length() == 0) {
            tvResult.setText(null);
            return;
        }
        try {
            evaluator.setAns(ans);
            tvResult.setText(getString(R.string.eq_prefix, Fmt.num(evaluator.eval(expr.toString(), degrees))));
        } catch (Exception e) {
            tvResult.setText(null);
        }
    }

    private void showHistory() {
        if (history.isEmpty()) {
            Toast.makeText(requireContext(), R.string.history_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        String[] items = history.toArray(new String[0]);
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.history_title)
                .setItems(items, (d, which) -> {
                    expr.setLength(0);
                    expr.append(items[which].substring(items[which].lastIndexOf(" = ") + 3));
                    justEvaluated = false;
                    updateDisplay(expr.length());
                })
                .setPositiveButton(R.string.dialog_clear, (d, w) -> history.clear())
                .setNegativeButton(R.string.dialog_close, null)
                .show();
    }
}