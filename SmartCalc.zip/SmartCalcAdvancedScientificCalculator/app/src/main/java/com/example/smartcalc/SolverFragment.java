package com.example.smartcalc;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartcalc.util.Fmt;

public class SolverFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_solver, parent, false);

        root.findViewById(R.id.btnSolveQ).setOnClickListener(v -> solveQuadratic(root));
        root.findViewById(R.id.btnSolve2).setOnClickListener(v -> solve2x2(root));
        root.findViewById(R.id.btnSolve3).setOnClickListener(v -> solve3x3(root));
        return root;
    }

    private double get(View root, int id) {
        try {
            String s = ((EditText) root.findViewById(id)).getText().toString().trim();
            return s.isEmpty() ? 0 : Double.parseDouble(s);
        } catch (NumberFormatException e) { return 0; }
    }

    private void solveQuadratic(View root) {
        TextView out = root.findViewById(R.id.resQ);
        double a = get(root, R.id.qA);
        double b = get(root, R.id.qB);
        double c = get(root, R.id.qC);

        if (a == 0) {
            if (b == 0) { out.setText(c == 0 ? "Infinite solutions" : "No solution"); return; }
            out.setText("Linear equation\nx = " + Fmt.num(-c / b));
            return;
        }

        double disc = b * b - 4 * a * c;
        StringBuilder sb = new StringBuilder();
        sb.append("Discriminant Δ = ").append(Fmt.num(disc)).append('\n');

        if (disc > 1e-12) {
            double r = Math.sqrt(disc);
            sb.append("Two real roots:\n");
            sb.append("x₁ = ").append(Fmt.num((-b + r) / (2 * a))).append('\n');
            sb.append("x₂ = ").append(Fmt.num((-b - r) / (2 * a)));
        } else if (disc > -1e-12) {
            sb.append("One real root:\n");
            sb.append("x = ").append(Fmt.num(-b / (2 * a)));
        } else {
            double re = -b / (2 * a);
            double im = Math.sqrt(-disc) / (2 * a);
            sb.append("Two complex roots:\n");
            sb.append("x₁ = ").append(Fmt.num(re)).append(" + ").append(Fmt.num(im)).append("i\n");
            sb.append("x₂ = ").append(Fmt.num(re)).append(" − ").append(Fmt.num(Math.abs(im))).append("i");
        }

        // Vertex
        double vx = -b / (2 * a);
        double vy = a * vx * vx + b * vx + c;
        sb.append("\nVertex: (").append(Fmt.num(vx)).append(", ").append(Fmt.num(vy)).append(')');

        out.setText(sb.toString());
    }

    private void solve2x2(View root) {
        TextView out = root.findViewById(R.id.res2);
        double a1 = get(root, R.id.l1a), b1 = get(root, R.id.l1b), c1 = get(root, R.id.l1c);
        double a2 = get(root, R.id.l2a), b2 = get(root, R.id.l2b), c2 = get(root, R.id.l2c);

        double d = a1 * b2 - a2 * b1;
        if (Math.abs(d) < 1e-12) {
            out.setText("No unique solution\n(determinant = 0)");
            return;
        }
        double x = (c1 * b2 - c2 * b1) / d;
        double y = (a1 * c2 - a2 * c1) / d;
        out.setText("x = " + Fmt.num(x) + "\ny = " + Fmt.num(y) + "\n\nΔ = " + Fmt.num(d));
    }

    private void solve3x3(View root) {
        TextView out = root.findViewById(R.id.res3);
        double[][] m = {
                {get(root, R.id.m1a), get(root, R.id.m1b), get(root, R.id.m1c)},
                {get(root, R.id.m2a), get(root, R.id.m2b), get(root, R.id.m2c)},
                {get(root, R.id.m3a), get(root, R.id.m3b), get(root, R.id.m3c)}
        };
        double[] d = {get(root, R.id.m1d), get(root, R.id.m2d), get(root, R.id.m3d)};

        double det = det3(m);
        if (Math.abs(det) < 1e-12) {
            out.setText("No unique solution\n(determinant = 0)");
            return;
        }
        double x = det3(replace(m, 0, d)) / det;
        double y = det3(replace(m, 1, d)) / det;
        double z = det3(replace(m, 2, d)) / det;
        out.setText("x = " + Fmt.num(x) + "\ny = " + Fmt.num(y)
                + "\nz = " + Fmt.num(z) + "\n\nΔ = " + Fmt.num(det));
    }

    private double det3(double[][] m) {
        return m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    }

    private double[][] replace(double[][] m, int col, double[] v) {
        double[][] c = new double[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                c[i][j] = (j == col) ? v[i] : m[i][j];
        return c;
    }
}