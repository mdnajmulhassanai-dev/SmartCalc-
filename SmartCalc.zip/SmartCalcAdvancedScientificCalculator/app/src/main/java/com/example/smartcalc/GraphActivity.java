package com.example.smartcalc;

import android.os.Bundle;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class GraphActivity extends AppCompatActivity {

    private GraphView graphView;
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        graphView = findViewById(R.id.graphView);
        input     = findViewById(R.id.fnInput);

        findViewById(R.id.plotBtn).setOnClickListener(v -> {
            graphView.setFunction(input.getText().toString());
            graphView.invalidate();
        });
        findViewById(R.id.resetBtn).setOnClickListener(v -> graphView.resetView());

        graphView.setFunction(input.getText().toString());
    }
}
