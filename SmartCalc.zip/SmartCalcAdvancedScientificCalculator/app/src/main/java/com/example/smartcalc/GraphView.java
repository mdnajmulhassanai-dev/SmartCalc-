package com.example.smartcalc;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.example.smartcalc.util.ExpressionEvaluator;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class GraphView extends View {

    private double xMin = -10, xMax = 10, yMin = -10, yMax = 10;

    private final Paint gridPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axisPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint curvePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);

    private String function = "sin(x)";
    private final ExpressionEvaluator evaluator = new ExpressionEvaluator();
    private final Map<String, Double> vars = new HashMap<>();

    private float lastX, lastY;
    private final ScaleGestureDetector scaleDetector;

    public GraphView(Context c, AttributeSet a) {
        super(c, a);
        gridPaint.setColor(Color.parseColor("#1F2630"));
        gridPaint.setStrokeWidth(1f);

        axisPaint.setColor(Color.parseColor("#8B949E"));
        axisPaint.setStrokeWidth(3f);

        curvePaint.setColor(Color.parseColor("#4ADE80"));
        curvePaint.setStrokeWidth(5f);
        curvePaint.setStyle(Paint.Style.STROKE);

        textPaint.setColor(Color.parseColor("#8B949E"));
        textPaint.setTextSize(28f);

        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                double f = d.getScaleFactor();
                double cx = xMin + (d.getFocusX() / getWidth())  * (xMax - xMin);
                double cy = yMax - (d.getFocusY() / getHeight()) * (yMax - yMin);
                xMin = cx + (xMin - cx) / f;
                xMax = cx + (xMax - cx) / f;
                yMin = cy + (yMin - cy) / f;
                yMax = cy + (yMax - cy) / f;
                invalidate();
                return true;
            }
        });
    }

    public void setFunction(String f) { this.function = f; }

    public void resetView() {
        xMin = -10; xMax = 10; yMin = -10; yMax = 10;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        if (!scaleDetector.isInProgress()) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = e.getX(); lastY = e.getY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    double dx = (e.getX() - lastX) / getWidth()  * (xMax - xMin);
                    double dy = (e.getY() - lastY) / getHeight() * (yMax - yMin);
                    xMin -= dx; xMax -= dx;
                    yMin += dy; yMax += dy;
                    lastX = e.getX(); lastY = e.getY();
                    invalidate();
                    return true;
            }
        }
        return true;
    }

    private double niceStep(double range) {
        double raw = range / 10.0;
        double mag = Math.pow(10, Math.floor(Math.log10(raw)));
        double norm = raw / mag;
        double step;
        if (norm < 1.5) step = 1;
        else if (norm < 3) step = 2;
        else if (norm < 7) step = 5;
        else step = 10;
        return step * mag;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth(), h = getHeight();

        // Grid
        double stepX = niceStep(xMax - xMin);
        double stepY = niceStep(yMax - yMin);

        double startX = Math.ceil(xMin / stepX) * stepX;
        for (double x = startX; x <= xMax; x += stepX) {
            float px = (float) ((x - xMin) / (xMax - xMin) * w);
            canvas.drawLine(px, 0, px, h, gridPaint);
        }
        double startY = Math.ceil(yMin / stepY) * stepY;
        for (double y = startY; y <= yMax; y += stepY) {
            float py = (float) (h - (y - yMin) / (yMax - yMin) * h);
            canvas.drawLine(0, py, w, py, gridPaint);
        }

        // Axes
        float zeroX = (float) ((0 - xMin) / (xMax - xMin) * w);
        float zeroY = (float) (h - (0 - yMin) / (yMax - yMin) * h);
        if (zeroX >= 0 && zeroX <= w) canvas.drawLine(zeroX, 0, zeroX, h, axisPaint);
        if (zeroY >= 0 && zeroY <= h) canvas.drawLine(0, zeroY, w, zeroY, axisPaint);

        // Axis labels
        for (double x = startX; x <= xMax; x += stepX) {
            if (Math.abs(x) < stepX / 2) continue;
            float px = (float) ((x - xMin) / (xMax - xMin) * w);
            canvas.drawText(String.format(Locale.US, "%.4g", x), px + 4,
                    Math.min(Math.max(zeroY + 30, 30), h - 6), textPaint);
        }
        for (double y = startY; y <= yMax; y += stepY) {
            if (Math.abs(y) < stepY / 2) continue;
            float py = (float) (h - (y - yMin) / (yMax - yMin) * h);
            canvas.drawText(String.format(Locale.US, "%.4g", y), Math.max(zeroX + 6, 6), py - 6, textPaint);
        }

        // Curve
        if (function == null || function.trim().isEmpty()) return;
        Path path = new Path();
        boolean started = false;
        float prevY = Float.NaN;

        for (int px = 0; px <= w; px++) {
            double x = xMin + (px / (double) w) * (xMax - xMin);
            vars.put("x", x);
            double y;
            try { y = evaluator.eval(function, false, vars); }
            catch (Exception ex) { y = Double.NaN; }

            if (Double.isNaN(y) || Double.isInfinite(y)) { started = false; prevY = Float.NaN; continue; }

            float py = (float) (h - (y - yMin) / (yMax - yMin) * h);

            if (!started || Float.isNaN(prevY) || Math.abs(py - prevY) > h * 1.5f) {
                path.moveTo(px, py);
                started = true;
            } else {
                path.lineTo(px, py);
            }
            prevY = py;
        }
        canvas.drawPath(path, curvePaint);
    }
}