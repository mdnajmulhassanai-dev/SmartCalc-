package com.example.smartcalc;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.smartcalc.util.Fmt;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ConverterFragment extends Fragment {

    private static final Map<String, Map<String, Double>> UNITS = new LinkedHashMap<>();
    private static final String[] CATEGORIES;

    static {
        Map<String, Double> length = new LinkedHashMap<>();
        length.put("Meter", 1.0); length.put("Kilometer", 1000.0);
        length.put("Centimeter", 0.01); length.put("Millimeter", 0.001);
        length.put("Micrometer", 1e-6); length.put("Mile", 1609.344);
        length.put("Yard", 0.9144); length.put("Foot", 0.3048);
        length.put("Inch", 0.0254); length.put("Nautical Mile", 1852.0);
        length.put("Light Year", 9.4607e15);
        UNITS.put("Length", length);

        Map<String, Double> mass = new LinkedHashMap<>();
        mass.put("Kilogram", 1.0); mass.put("Gram", 0.001);
        mass.put("Milligram", 1e-6); mass.put("Tonne", 1000.0);
        mass.put("Pound", 0.45359237); mass.put("Ounce", 0.028349523125);
        mass.put("Stone", 6.35029318);
        UNITS.put("Mass", mass);

        Map<String, Double> area = new LinkedHashMap<>();
        area.put("Square Meter", 1.0); area.put("Square Kilometer", 1e6);
        area.put("Square Centimeter", 1e-4); area.put("Hectare", 1e4);
        area.put("Acre", 4046.8564224); area.put("Square Foot", 0.09290304);
        area.put("Square Inch", 0.00064516); area.put("Square Mile", 2589988.110336);
        UNITS.put("Area", area);

        Map<String, Double> volume = new LinkedHashMap<>();
        volume.put("Liter", 1.0); volume.put("Milliliter", 0.001);
        volume.put("Cubic Meter", 1000.0); volume.put("Cubic Centimeter", 0.001);
        volume.put("Gallon (US)", 3.785411784); volume.put("Quart (US)", 0.946352946);
        volume.put("Pint (US)", 0.473176473); volume.put("Cup (US)", 0.2365882365);
        volume.put("Fluid Ounce (US)", 0.0295735295625);
        volume.put("Tablespoon", 0.01478676478125);
        UNITS.put("Volume", volume);

        Map<String, Double> speed = new LinkedHashMap<>();
        speed.put("Meter/second", 1.0); speed.put("Kilometer/hour", 1 / 3.6);
        speed.put("Mile/hour", 0.44704); speed.put("Foot/second", 0.3048);
        speed.put("Knot", 0.514444444);
        UNITS.put("Speed", speed);

        Map<String, Double> time = new LinkedHashMap<>();
        time.put("Second", 1.0); time.put("Millisecond", 0.001);
        time.put("Minute", 60.0); time.put("Hour", 3600.0);
        time.put("Day", 86400.0); time.put("Week", 604800.0);
        time.put("Year", 31557600.0);
        UNITS.put("Time", time);

        Map<String, Double> data = new LinkedHashMap<>();
        data.put("Byte", 1.0); data.put("Kilobyte", 1024.0);
        data.put("Megabyte", 1048576.0); data.put("Gigabyte", 1073741824.0);
        data.put("Terabyte", 1099511627776.0); data.put("Bit", 0.125);
        UNITS.put("Data", data);

        Map<String, Double> energy = new LinkedHashMap<>();
        energy.put("Joule", 1.0); energy.put("Kilojoule", 1000.0);
        energy.put("Calorie", 4.184); energy.put("Kilocalorie", 4184.0);
        energy.put("Watt-hour", 3600.0); energy.put("Kilowatt-hour", 3.6e6);
        energy.put("Electronvolt", 1.602176634e-19);
        UNITS.put("Energy", energy);

        Map<String, Double> pressure = new LinkedHashMap<>();
        pressure.put("Pascal", 1.0); pressure.put("Kilopascal", 1000.0);
        pressure.put("Bar", 100000.0); pressure.put("Atmosphere", 101325.0);
        pressure.put("PSI", 6894.757293168); pressure.put("Torr", 133.322368421);
        UNITS.put("Pressure", pressure);

        Map<String, Double> temperature = new LinkedHashMap<>();
        temperature.put("Celsius", 1.0); temperature.put("Fahrenheit", 1.0);
        temperature.put("Kelvin", 1.0);
        UNITS.put("Temperature", temperature);

        CATEGORIES = UNITS.keySet().toArray(new String[0]);
    }

    private Spinner spCategory, spFrom, spTo;
    private EditText etFrom, etTo;
    private TextView tvFormula;
    private boolean updating = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup parent,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_converter, parent, false);

        spCategory = root.findViewById(R.id.spCategory);
        spFrom     = root.findViewById(R.id.spFrom);
        spTo       = root.findViewById(R.id.spTo);
        etFrom     = root.findViewById(R.id.etFrom);
        etTo       = root.findViewById(R.id.etTo);
        tvFormula  = root.findViewById(R.id.tvFormula);

        spCategory.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_dropdown_item, CATEGORIES));

        spCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                loadUnits(CATEGORIES[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        AdapterView.OnItemSelectedListener recalc = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { convert(); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        };
        spFrom.setOnItemSelectedListener(recalc);
        spTo.setOnItemSelectedListener(recalc);

        etFrom.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { convert(); }
        });

        loadUnits(CATEGORIES[0]);
        return root;
    }

    private void loadUnits(String category) {
        Map<String, Double> units = UNITS.get(category);
        List<String> names = new ArrayList<>(units.keySet());
        ArrayAdapter<String> ad = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_dropdown_item, names);
        spFrom.setAdapter(ad);
        spTo.setAdapter(ad);
        if (names.size() > 1) spTo.setSelection(1);
        convert();
    }

    private void convert() {
        if (updating) return;
        updating = true;
        try {
            String cat = (String) spCategory.getSelectedItem();
            String from = (String) spFrom.getSelectedItem();
            String to   = (String) spTo.getSelectedItem();
            if (cat == null || from == null || to == null) return;

            String txt = etFrom.getText().toString().trim();
            if (txt.isEmpty() || txt.equals("-") || txt.equals(".")) { etTo.setText(""); return; }

            double value;
            try { value = Double.parseDouble(txt); }
            catch (NumberFormatException e) { etTo.setText(""); return; }

            double result;
            if ("Temperature".equals(cat)) {
                double celsius = toCelsius(from, value);
                result = fromCelsius(to, celsius);
                tvFormula.setText(String.format("%s  →  %s", from, to));
            } else {
                Map<String, Double> units = UNITS.get(cat);
                double base = value * units.get(from);
                result = base / units.get(to);
                tvFormula.setText("1 " + from + " = "
                        + Fmt.num(units.get(from) / units.get(to)) + " " + to);
            }
            etTo.setText(Fmt.num(result));
        } finally {
            updating = false;
        }
    }

    private double toCelsius(String unit, double v) {
        switch (unit) {
            case "Fahrenheit": return (v - 32) * 5 / 9;
            case "Kelvin":     return v - 273.15;
            default:           return v;
        }
    }

    private double fromCelsius(String unit, double c) {
        switch (unit) {
            case "Fahrenheit": return c * 9 / 5 + 32;
            case "Kelvin":     return c + 273.15;
            default:           return c;
        }
    }
}