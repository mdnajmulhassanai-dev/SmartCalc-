plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.smartcalc"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.smartcalc"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Latest stable (May 2024+)
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.core:core:1.13.1")

    // Test deps — updated to current stable (fixes remaining "Obsolete" flags)
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}